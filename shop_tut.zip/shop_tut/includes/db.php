<?php 
$DB_HOST = 'localhost';
$DB_USER = 'USER';
$DB_PASS = 'PASS';
$DB_NAME = 'DB';
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>
